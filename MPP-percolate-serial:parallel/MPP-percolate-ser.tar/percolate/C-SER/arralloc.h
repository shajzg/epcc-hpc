void *arralloc(size_t size, int ndim, ...);
